# Exercises
![exercises12-1](https://user-images.githubusercontent.com/70604577/160039403-8309aec7-863c-4de7-b454-f20f2c9219cd.png)
![exercises12-2](https://user-images.githubusercontent.com/70604577/160039412-ab647b28-bef9-4e2e-b3ee-b6e1bff5a86c.png)
