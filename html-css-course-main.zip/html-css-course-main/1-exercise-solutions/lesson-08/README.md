# Exercises
![exercises8-1](https://user-images.githubusercontent.com/70604577/160038872-e34429d8-6e44-4066-8a96-03f3d2a32f68.png)
![exercises8-2](https://user-images.githubusercontent.com/70604577/160038875-6ac0fc2d-c2bc-4149-b48d-682bdaf603ec.png)
