## HTML and CSS Course Materials
📚 Watch the course here: https://youtu.be/G3e-cpL7ofc

1. [Exercise solutions](1-exercise-solutions)
2. [Copy of the code](2-copy-of-code) at the end of each lesson
3. [Extra resources](3-extra)

🎓 A certificate of completion is available for this course here: https://courses.supersimple.dev/courses/html-css